module Java #:nodoc: all
  module javafx
    module animation
    end
    module beans
      module value
      end
    end
    module scene
      module chart
      end
      module control
      end
      module effect
      end
      module layout
      end
      module media
      end
      module paint
      end
      module shape
      end
      module transform
      end
    end
    module stage
    end
  end
end
