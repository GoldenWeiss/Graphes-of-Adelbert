module JRubyFX
  # Current gem version. Used in rake task.
  VERSION='1.2.0'
end
